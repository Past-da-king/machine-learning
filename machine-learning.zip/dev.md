

## data_utils.py

```python
# FULL, COMPLETE, READY-TO-RUN CODE ONLY.
# NO SNIPPETS. NO PLACEHOLDERS. NO INCOMPLETE SECTIONS.

import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, random_split # Import random_split
from PIL import Image
import os

# Import configuration for consistency
import config

# --- Transforms (Remain the same) ---
train_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(config.FASHION_MNIST_MEAN, config.FASHION_MNIST_STD)
])

test_transform = transforms.Compose([ # Test and Validation use the same transform
    transforms.ToTensor(),
    transforms.Normalize(config.FASHION_MNIST_MEAN, config.FASHION_MNIST_STD)
])

predict_transform = transforms.Compose([
    transforms.Resize((28, 28)),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize(config.FASHION_MNIST_MEAN, config.FASHION_MNIST_STD)
])

# --- Data Loading Function (Modified) ---
def get_dataloaders(batch_size, data_dir=config.DATA_DIR, num_workers=config.NUM_WORKERS, val_split=0.2):
    """
    Loads the FashionMNIST dataset and creates training, validation, and testing DataLoaders.
    The validation set is split from the original training set.

    Args:
        batch_size (int): The number of samples per batch.
        data_dir (str): The directory where the FashionMNIST dataset is stored.
        num_workers (int): How many subprocesses to use for data loading.
        val_split (float): The fraction of the training data to use for validation (e.g., 0.2 for 20%).

    Returns:
        tuple: (train_loader, val_loader, test_loader) or (None, None, None) if dataset not found.
    """
    fashion_mnist_path = os.path.join(data_dir, "FashionMNIST")
    raw_folder_path = os.path.join(fashion_mnist_path, "raw")

    if not os.path.isdir(raw_folder_path):
        print(f"Error: 'FashionMNIST/raw' directory not found in '{os.path.abspath(data_dir)}'.")
        return None, None, None

    try:
        # Load the full original training dataset
        full_train_dataset = datasets.FashionMNIST(
            root=data_dir,
            train=True,
            download=False,
            transform=train_transform # Apply training transforms initially
        )

        # Load the test dataset
        test_dataset = datasets.FashionMNIST(
            root=data_dir,
            train=False,
            download=False,
            transform=test_transform # Apply test transforms
        )

        # Calculate split sizes
        num_train = len(full_train_dataset)
        num_val = int(val_split * num_train)
        num_train_new = num_train - num_val

        if num_train_new <= 0 or num_val <= 0:
             raise ValueError(f"Invalid split sizes. Train: {num_train_new}, Validation: {num_val}")

        print(f"Splitting original training data ({num_train}) into New Train ({num_train_new}) and Validation ({num_val})...")

        # Split the original training dataset into new training and validation sets
        # Use a fixed generator for reproducibility if needed
        # generator = torch.Generator().manual_seed(42) # Optional reproducibility
        # train_dataset, val_dataset = random_split(full_train_dataset, [num_train_new, num_val], generator=generator)
        train_dataset, val_dataset = random_split(full_train_dataset, [num_train_new, num_val])

        # --- Important Note on Transforms ---
        # By default, random_split shares the underlying dataset.
        # If you had different transforms for train vs validation (e.g., data augmentation only on train),
        # you might need to apply transforms *after* the split or create custom Dataset wrappers.
        # Here, train_transform and test_transform are the same except for potential augmentation (which we aren't using),
        # so applying train_transform before the split is acceptable for this specific case.
        # For validation, we use the test_transform implicitly as it's identical here.


        # Create dataloaders
        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True, # Shuffle training data
            num_workers=num_workers,
            pin_memory=True if config.DEVICE == 'cuda' else False
        )
        val_loader = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False, # No need to shuffle validation data
            num_workers=num_workers,
            pin_memory=True if config.DEVICE == 'cuda' else False
        )
        test_loader = DataLoader(
            test_dataset,
            batch_size=batch_size,
            shuffle=False, # No need to shuffle test data
            num_workers=num_workers,
            pin_memory=True if config.DEVICE == 'cuda' else False
        )

        print("Datasets loaded and split successfully.")
        print(f"Training batches: {len(train_loader)}, Validation batches: {len(val_loader)}, Test batches: {len(test_loader)}")
        return train_loader, val_loader, test_loader

    except RuntimeError as e:
         print(f"Error loading dataset via torchvision: {e}")
         return None, None, None
    except ValueError as e:
         print(f"Error during dataset split: {e}")
         return None, None, None
    except Exception as e:
        print(f"An unexpected error occurred during data loading/splitting: {e}")
        return None, None, None

# Optional mean/std calculation function remains the same
# def calculate_fashion_mnist_mean_std...

```

---

## engine.py

```python
# FULL, COMPLETE, READY-TO-RUN CODE ONLY.
# NO SNIPPETS. NO PLACEHOLDERS. NO INCOMPLETE SECTIONS.

import torch
import os
# from tqdm.auto import tqdm # Optional: for progress bars

# Import config for device and log file settings
import config

# --- Evaluation/Validation Function (Generalized) ---
def evaluate_model(model, criterion, data_loader, device, log_file, phase="Test"):
    """Evaluates the model on a given dataset (validation or test)."""
    print(f"\n--- Evaluating Model ({phase}) ---")
    model.eval()  # Set model to evaluation mode
    running_loss = 0.0
    correct = 0
    total = 0

    try:
        with torch.no_grad():  # No need to track gradients
            for inputs, labels in data_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                running_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        avg_loss = running_loss / len(data_loader)
        accuracy = 100 * correct / total
        print(f'{phase} Loss: {avg_loss:.4f} | {phase} Accuracy: {accuracy:.2f}%')

        # Append results to the log file
        with open(log_file, 'a') as f:
            f.write(f"\n--- {phase} Results ---\n")
            f.write(f"{phase} Accuracy: {accuracy:.2f}%\n")
            f.write(f"{phase} Loss: {avg_loss:.4f}\n")
        print(f"--- {phase} Evaluation Complete ---")
        return accuracy, avg_loss # Return performance metrics

    except IOError as e:
        print(f"Error writing {phase} results to log file '{log_file}': {e}")
        return 0.0, float('inf') # Indicate failure
    except Exception as e:
        print(f"An unexpected error occurred during {phase} evaluation: {e}")
        return 0.0, float('inf') # Indicate failure


# --- Training Function (Modified to include validation) ---
def train_model(model, criterion, optimizer, train_loader, val_loader, device, epochs, log_file):
    """Trains the neural network model, performing validation after each epoch."""
    print("\n--- Starting Training (with Validation) ---")
    # Ensure log file directory exists
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir)

    best_val_accuracy = 0.0 # Keep track of best validation accuracy

    try:
        with open(log_file, 'a') as f: # Append to log file
            f.write("\n--- Training Log ---\n")
            f.write(f"Epochs: {epochs}, Batch Size: {config.BATCH_SIZE}, LR: {config.LEARNING_RATE}, Val Split: {0.2}\n") # Log hyperparams

            for epoch in range(epochs):
                model.train() # Set model to training mode for the epoch
                running_loss = 0.0
                # progress_bar = tqdm(enumerate(train_loader), total=len(train_loader), desc=f"Epoch {epoch+1}/{epochs} Training") # Optional TQDM
                # for i, (inputs, labels) in progress_bar:
                for i, (inputs, labels) in enumerate(train_loader):
                    inputs, labels = inputs.to(device), labels.to(device)
                    optimizer.zero_grad()
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)
                    loss.backward()
                    optimizer.step()
                    running_loss += loss.item()
                    # if isinstance(progress_bar, tqdm): progress_bar.set_postfix(loss=loss.item()) # Optional TQDM

                epoch_loss = running_loss / len(train_loader)
                print(f"\nEpoch [{epoch + 1}/{epochs}] Training Loss: {epoch_loss:.4f}")
                f.write(f"\nEpoch [{epoch + 1}/{epochs}] Training Loss: {epoch_loss:.4f}\n")

                # --- Validation Step ---
                val_accuracy, val_loss = evaluate_model(model, criterion, val_loader, device, log_file, phase="Validation")
                # Log validation results per epoch
                f.write(f"Epoch [{epoch + 1}/{epochs}] Validation Loss: {val_loss:.4f} | Validation Accuracy: {val_accuracy:.2f}%\n")

                # --- Optional: Save best model based on validation accuracy ---
                if val_accuracy > best_val_accuracy:
                    best_val_accuracy = val_accuracy
                    # Construct model path inside the loop if saving best model
                    model_path = os.path.join(config.MODEL_SAVE_DIR, config.MODEL_NAME) # Use configured path
                    try:
                         torch.save(model.state_dict(), model_path)
                         print(f"Epoch [{epoch + 1}/{epochs}]: New best model saved to {model_path} with Validation Accuracy: {best_val_accuracy:.2f}%")
                         f.write(f"Epoch [{epoch + 1}/{epochs}]: Saved new best model.\n")
                    except Exception as e_save:
                         print(f"Error saving best model during epoch {epoch + 1}: {e_save}")
                         f.write(f"Epoch [{epoch + 1}/{epochs}]: Error saving best model: {e_save}\n")
                # -------------------------------------------------------------

        print("\n--- Finished Training ---")

    except IOError as e:
        print(f"Error writing to log file '{log_file}': {e}")
    except Exception as e:
        print(f"An unexpected error occurred during training: {e}")
        # import traceback # For debugging
        # print(traceback.format_exc())

```

---

## main.py

```python
# FULL, COMPLETE, READY-TO-RUN CODE ONLY.
# NO SNIPPETS. NO PLACEHOLDERS. NO INCOMPLETE SECTIONS.

import torch
import torch.nn as nn
import torch.optim as optim
import os
import sys

# Import modules from the project
import config
from model import SimpleANN
from data_utils import get_dataloaders, predict_transform # predict_transform still needed
from engine import train_model, evaluate_model # evaluate_model now handles both validation and test
from predict import predict_image

# --- Main Execution ---
if __name__ == "__main__":

    # --- Setup ---
    if os.path.exists(config.LOG_FILE):
        try:
            os.remove(config.LOG_FILE)
            print(f"Cleared previous log file: {config.LOG_FILE}")
        except OSError as e:
            print(f"Warning: Could not remove previous log file '{config.LOG_FILE}': {e}")

    device = config.DEVICE
    print(f"Using device: {device}")

    model_path = os.path.join(config.MODEL_SAVE_DIR, config.MODEL_NAME)
    if config.MODEL_SAVE_DIR and not os.path.exists(config.MODEL_SAVE_DIR):
        os.makedirs(config.MODEL_SAVE_DIR)
        print(f"Created model save directory: {config.MODEL_SAVE_DIR}")

    # --- Data Loading (Now gets 3 loaders) ---
    train_loader, val_loader, test_loader = get_dataloaders(
        batch_size=config.BATCH_SIZE,
        data_dir=config.DATA_DIR,
        num_workers=config.NUM_WORKERS,
        val_split=0.2 # Example: 20% validation split
    )

    # Exit if data loading failed
    if train_loader is None or val_loader is None or test_loader is None:
        print("Failed to load or split datasets. Exiting.")
        sys.exit(1)

    # --- Model Initialization ---
    model = SimpleANN(input_size=config.INPUT_SIZE, num_classes=config.NUM_CLASSES).to(device)
    print(f"Model initialized: {type(model).__name__}")

    # --- Loss and Optimizer ---
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=config.LEARNING_RATE)

    # --- Training ---
    # We generally train from scratch when using validation sets properly,
    # or load a previously best-saved model if resuming.
    # For this structure, let's always train and save the best based on validation.
    print(f"\nStarting training for {config.EPOCHS} epochs...")
    train_model(
        model=model,
        criterion=criterion,
        optimizer=optimizer,
        train_loader=train_loader,
        val_loader=val_loader, # Pass validation loader
        device=device,
        epochs=config.EPOCHS,
        log_file=config.LOG_FILE
    )

    # --- Final Evaluation on Test Set ---
    # Load the *best* model saved during training (based on validation accuracy)
    print(f"\nLoading best model saved at {model_path} for final test evaluation...")
    try:
        # Ensure we load the state dict saved based on validation performance
        if os.path.exists(model_path):
            model.load_state_dict(torch.load(model_path, map_location=device))
            print("Best model loaded successfully.")
            # Perform final evaluation on the *test* set
            evaluate_model(
                model=model,
                criterion=criterion,
                data_loader=test_loader, # Use TEST loader here
                device=device,
                log_file=config.LOG_FILE,
                phase="Test" # Explicitly label as Test phase
            )
        else:
             print(f"Warning: Model file '{model_path}' not found after training. Could not perform final test evaluation.")

    except Exception as e:
        print(f"Error loading best model or during final test evaluation: {e}")


    print("\n--- Setup Complete ---")

    # --- Interactive Prediction Loop (Remains the same) ---
    print("\nEnter image filepath for classification or 'exit' to quit.")
    while True:
        try:
            filepath = input("Please enter a filepath: ")
            if filepath.lower().strip() == 'exit':
                print("Exiting...")
                break

            # Ensure the model is loaded (it should be from the step above)
            if not os.path.exists(model_path) and 'model' not in locals():
                 print("Error: Model not available for prediction.")
                 continue # Or exit

            # Predict the class of the image
            predicted_class, confidence = predict_image(
                model=model,
                image_path=filepath,
                transform=predict_transform,
                class_names=config.CLASS_NAMES,
                device=device
            )

            if predicted_class is not None:
                 print(f"Classifier: {predicted_class}")

        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"An unexpected error occurred in the prediction loop: {e}")


```

